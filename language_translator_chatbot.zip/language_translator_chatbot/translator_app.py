import streamlit as st
from langdetect import detect
from gtts import gTTS
import os
from google.generativeai import configure, GenerativeModel
from dotenv import load_dotenv

# Load .env for API key
load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

# Configure Gemini
configure(api_key=GOOGLE_API_KEY)
model = GenerativeModel("gemini-1.5-flash")

lang_codes = {
    "French": "fr", "Spanish": "es", "Arabic": "ar", "Urdu": "ur",
    "German": "de", "Chinese": "zh", "Russian": "ru", "English": "en"
}

def get_lang_code(language):
    return lang_codes.get(language, "en")

st.set_page_config(page_title="Language Translator Chatbot", layout="centered")
st.title("🌍 Language Translator Chatbot with TTS & Detection")

text_input = st.text_area("✍️ Enter text to translate")
target_language = st.selectbox("🌐 Select target language", list(lang_codes.keys()))

if st.button("🔁 Translate"):
    if text_input.strip() == "":
        st.warning("Please enter some text.")
    else:
        try:
            detected_lang = detect(text_input)
            st.markdown(f"🔍 **Detected Language:** `{detected_lang}`")

            prompt = (
                f"Translate the following text from language code '{detected_lang}' "
                f"to language code '{get_lang_code(target_language)}'. "
                f"The translation MUST be in the target language only.\n\nText: {text_input}"
            )
            response = model.generate_content(prompt)
            translated_text = response.text.strip()

            st.success("Translation:")
            st.write(translated_text)

            tts = gTTS(text=translated_text, lang=get_lang_code(target_language))
            tts.save("translated_audio.mp3")
            audio_file = open("translated_audio.mp3", "rb")
            st.audio(audio_file.read(), format="audio/mp3")
        except Exception as e:
            st.error(f"❌ Error: {e}")
