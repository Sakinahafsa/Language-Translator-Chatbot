# 🌍 Language Translator Chatbot with TTS & Detection

## ✅ Features
- Detects input language automatically
- Translates text into Arabic, Urdu, French, and more
- Speaks the translation using Google TTS
- Built using Streamlit, Gemini API, gTTS, LangDetect

## 🛠️ Installation & Run

1. Create a virtual environment (optional but recommended):
```bash
python -m venv venv
venv\\Scripts\\activate  # For Windows
